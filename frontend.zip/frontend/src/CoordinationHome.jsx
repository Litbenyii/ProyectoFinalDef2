import React, { useEffect, useState } from "react";
import {
  getCoordinatorPracticeRequests,
  approvePracticeRequest,
  rejectPracticeRequest,
  getCoordOffers,
  createOffer,
  deactivateOffer,
  getCoordinatorApplications,
  approveApplication,
  rejectApplication,
  createStudent,
  getEvaluators,
  getOpenPractices,
  assignEvaluatorToPractice,
} from "./api";

/* =============================
   COMPONENTE PRINCIPAL
============================= */

export default function CoordinationHome({ name, onLogout, token }) {
  const [activeTab, setActiveTab] = useState("external");

  const [externalRequests, setExternalRequests] = useState([]);
  const [offers, setOffers] = useState([]);
  const [applications, setApplications] = useState([]);
  const [evaluators, setEvaluators] = useState([]);
  const [openPractices, setOpenPractices] = useState([]);

  const [loading, setLoading] = useState(true);
  const [msg, setMsg] = useState("");
  const [error, setError] = useState("");

  const [offerForm, setOfferForm] = useState({
    title: "",
    company: "",
    location: "",
    hours: "",
    modality: "",
    details: "",
    startDate: "",
    deadline: "",
  });

  const [studentForm, setStudentForm] = useState({
    rut: "",
    name: "",
    email: "",
    career: "",
  });

  const [assignForm, setAssignForm] = useState({
    practiceId: "",
    evaluatorId: "",
  });

  /* ================= LOAD DATA ================= */

  const loadAll = async () => {
    try {
      setLoading(true);
      setError("");
      setMsg("");

      const [
        external,
        offersData,
        apps,
        evals,
        practices,
      ] = await Promise.all([
        getCoordinatorPracticeRequests(token),
        getCoordOffers(token),
        getCoordinatorApplications(token),
        getEvaluators(token),
        getOpenPractices(token),
      ]);

      setExternalRequests(external || []);
      setOffers(offersData || []);
      setApplications(apps || []);
      setEvaluators(evals || []);
      setOpenPractices(practices || []);
    } catch (err) {
      setError(err.message || "Error cargando datos");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (token) loadAll();
  }, [token]);

  /* ================= HANDLERS ================= */

  const handleOfferChange = (e) =>
    setOfferForm({ ...offerForm, [e.target.name]: e.target.value });

  const handleStudentChange = (e) =>
    setStudentForm({ ...studentForm, [e.target.name]: e.target.value });

  const handleAssignChange = (e) =>
    setAssignForm({ ...assignForm, [e.target.name]: e.target.value });

  const handleCreateOffer = async (e) => {
    e.preventDefault();
    await createOffer(token, {
      ...offerForm,
      hours: offerForm.hours ? Number(offerForm.hours) : null,
    });
    setMsg("Oferta creada correctamente");
    setOfferForm({
      title: "",
      company: "",
      location: "",
      hours: "",
      modality: "",
      details: "",
      startDate: "",
      deadline: "",
    });
    loadAll();
  };

  const handleDeactivateOffer = async (id) => {
    await deactivateOffer(token, id);
    setMsg("Oferta desactivada");
    loadAll();
  };

  const handleExternalDecision = async (id, action) => {
    action === "approve"
      ? await approvePracticeRequest(token, id)
      : await rejectPracticeRequest(token, id);
    setMsg(action === "approve" ? "Solicitud aprobada" : "Solicitud rechazada");
    loadAll();
  };

  const handleApplicationDecision = async (id, action) => {
    action === "approve"
      ? await approveApplication(token, id)
      : await rejectApplication(token, id);
    setMsg(action === "approve" ? "Postulación aprobada" : "Postulación rechazada");
    loadAll();
  };

  const handleCreateStudent = async (e) => {
    e.preventDefault();
    await createStudent(token, studentForm);
    setMsg("Estudiante registrado");
    setStudentForm({ rut: "", name: "", email: "", career: "" });
  };

  const handleAssignEvaluator = async (e) => {
    e.preventDefault();
    await assignEvaluatorToPractice(
      token,
      assignForm.practiceId,
      assignForm.evaluatorId
    );
    setMsg("Evaluador asignado");
    setAssignForm({ practiceId: "", evaluatorId: "" });
    loadAll();
  };

  /* ================= UI ================= */

  return (
    <div className="min-h-screen bg-slate-50">
      <header className="bg-slate-900 text-white py-4 px-6 flex justify-between">
        <div>
          <h1 className="text-lg font-semibold">Coordinación de Prácticas</h1>
          <p className="text-xs text-slate-300">Usuario: {name}</p>
        </div>
        <button
          onClick={onLogout}
          className="bg-white text-slate-900 px-4 py-1.5 rounded-full text-xs font-medium"
        >
          Cerrar sesión
        </button>
      </header>

      <nav className="max-w-6xl mx-auto px-4 pt-6">
        <div className="inline-flex rounded-full bg-slate-100 p-1 text-xs">
          <TabButton label="Solicitudes externas" active={activeTab === "external"} onClick={() => setActiveTab("external")} />
          <TabButton label="Ofertas" active={activeTab === "offers"} onClick={() => setActiveTab("offers")} />
          <TabButton label="Postulaciones" active={activeTab === "applications"} onClick={() => setActiveTab("applications")} />
          <TabButton label="Estudiantes / Evaluadores" active={activeTab === "students"} onClick={() => setActiveTab("students")} />
        </div>
      </nav>

      <main className="max-w-6xl mx-auto px-4 py-6">
        {loading && <p className="text-sm text-slate-500">Cargando...</p>}
        {msg && <p className="text-sm text-emerald-600">{msg}</p>}
        {error && <p className="text-sm text-red-600">{error}</p>}
      </main>
    </div>
  );
}

/* ================= COMPONENTES ================= */

function TabButton({ label, active, onClick }) {
  return (
    <button
      type="button"
      onClick={onClick}
      className={`px-4 py-1.5 rounded-full text-xs font-medium transition
        ${active
          ? "bg-white text-slate-900 shadow-sm"
          : "text-slate-500 hover:text-slate-900"}
      `}
    >
      {label}
    </button>
  );
}
