import React, { useEffect, useState } from "react";
import {
  getOffers,
  getMyRequests,
  createPracticeRequest,
  createApplication,
} from "./api";

export default function StudentHome({ name, onLogout, token }) {
  const [offers, setOffers] = useState([]);
  const [requests, setRequests] = useState([]);
  const [loading, setLoading] = useState(true);
  const [msg, setMsg] = useState("");
  const [error, setError] = useState("");
  const [applyingId, setApplyingId] = useState(null);
  const [savingExternal, setSavingExternal] = useState(false);

  const [practiceForm, setPracticeForm] = useState({
    company: "",
    tutorName: "",
    tutorEmail: "",
    startDate: "",
    endDate: "",
    details: "",
  });

  const loadData = async () => {
    try {
      setLoading(true);
      setError("");
      setMsg("");

      const [offersData, requestsData] = await Promise.all([
        getOffers(token),
        getMyRequests(token),
      ]);

      setOffers(Array.isArray(offersData) ? offersData : []);
      setRequests(Array.isArray(requestsData) ? requestsData : []);
    } catch (err) {
      setError(err.message || "Error al cargar datos");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (!token) return;
    loadData();
  }, [token]);

  const handlePracticeChange = (e) => {
    const { name, value } = e.target;
    setPracticeForm((prev) => ({ ...prev, [name]: value }));
  };

  const handlePracticeSubmit = async (e) => {
    e.preventDefault();
    setError("");
    setMsg("");

    if (!practiceForm.company || !practiceForm.tutorName || !practiceForm.tutorEmail) {
      setError("Complete empresa, tutor y correo del tutor.");
      return;
    }

    try {
      setSavingExternal(true);
      await createPracticeRequest(token, practiceForm);
      setMsg("Solicitud de práctica externa enviada.");
      setPracticeForm({
        company: "",
        tutorName: "",
        tutorEmail: "",
        startDate: "",
        endDate: "",
        details: "",
      });
      await loadData();
    } catch (err) {
      setError(err.message || "Error al enviar práctica externa");
    } finally {
      setSavingExternal(false);
    }
  };

  const handleApplyOffer = async (offerId) => {
    setError("");
    setMsg("");
    try {
      setApplyingId(offerId);
      await createApplication(token, offerId);
      setMsg("Postulación enviada correctamente.");
      await loadData();
    } catch (err) {
      setError(err.message || "Error al postular");
    } finally {
      setApplyingId(null);
    }
  };

  return (
    <div className="min-h-screen bg-slate-50">
      <header className="bg-slate-900 text-white py-4 px-6 flex items-center justify-between">
        <div>
          <h1 className="text-lg font-semibold">Portal de prácticas — Estudiante</h1>
          <p className="text-xs text-slate-200">Conectado como {name}</p>
        </div>
        <button
          onClick={onLogout}
          className="px-4 py-1.5 rounded-full text-xs font-medium bg-white text-slate-900 hover:bg-slate-100"
        >
          Cerrar sesión
        </button>
      </header>

      <main className="max-w-6xl mx-auto px-4 py-8 space-y-8">
        {(msg || error) && (
          <div>
            {msg && <div className="mb-2 p-2 text-sm bg-emerald-50 text-emerald-700 rounded">{msg}</div>}
            {error && <div className="p-2 text-sm bg-red-50 text-red-700 rounded">{error}</div>}
          </div>
        )}

        <section className="grid gap-6 lg:grid-cols-2">
          <div className="bg-white rounded-2xl shadow-sm p-6 border">
            <h2 className="font-semibold mb-4">Ofertas internas</h2>

            {loading ? (
              <p className="text-sm text-slate-500">Cargando…</p>
            ) : offers.length === 0 ? (
              <p className="text-sm text-slate-500">No hay ofertas disponibles.</p>
            ) : (
              <div className="space-y-3">
                {offers.map((offer) => (
                  <div key={offer.id} className="p-4 rounded-xl border bg-slate-50">
                    <div className="flex justify-between mb-1">
                      <div>
                        <p className="font-semibold">{offer.title}</p>
                        <p className="text-xs text-slate-500">{offer.company}</p>
                      </div>
                      <button
                        onClick={() => handleApplyOffer(offer.id)}
                        disabled={applyingId === offer.id}
                        className="text-xs px-3 py-1.5 bg-slate-900 text-white rounded disabled:opacity-50"
                      >
                        {applyingId === offer.id ? "Enviando…" : "Postular"}
                      </button>
                    </div>
                    {offer.details && (
                      <p className="text-xs text-slate-600">{offer.details}</p>
                    )}
                  </div>
                ))}
              </div>
            )}
          </div>

          <div className="bg-white rounded-2xl shadow-sm p-6 border">
            <h2 className="font-semibold mb-4">Práctica externa</h2>

            <form onSubmit={handlePracticeSubmit} className="space-y-3">
              <input
                name="company"
                placeholder="Empresa"
                value={practiceForm.company}
                onChange={handlePracticeChange}
                className="w-full border p-2 rounded text-sm"
              />
              <input
                name="tutorName"
                placeholder="Tutor"
                value={practiceForm.tutorName}
                onChange={handlePracticeChange}
                className="w-full border p-2 rounded text-sm"
              />
              <input
                name="tutorEmail"
                type="email"
                placeholder="Correo tutor"
                value={practiceForm.tutorEmail}
                onChange={handlePracticeChange}
                className="w-full border p-2 rounded text-sm"
              />
              <textarea
                name="details"
                placeholder="Detalles"
                value={practiceForm.details}
                onChange={handlePracticeChange}
                className="w-full border p-2 rounded text-sm"
              />
              <button
                type="submit"
                disabled={savingExternal}
                className="w-full bg-slate-900 text-white py-2 rounded text-sm disabled:opacity-50"
              >
                {savingExternal ? "Enviando…" : "Enviar solicitud"}
              </button>
            </form>
          </div>
        </section>

        <section className="bg-white rounded-2xl shadow-sm p-6 border">
          <h2 className="font-semibold mb-4">Mis solicitudes</h2>

          {loading ? (
            <p className="text-sm text-slate-500">Cargando…</p>
          ) : requests.length === 0 ? (
            <p className="text-sm text-slate-500">Sin registros.</p>
          ) : (
            <table className="w-full text-xs">
              <thead>
                <tr className="text-slate-500 border-b">
                  <th className="py-2 text-left">Tipo</th>
                  <th className="py-2 text-left">Empresa / Oferta</th>
                  <th className="py-2 text-left">Estado</th>
                </tr>
              </thead>
              <tbody>
                {requests.map((r) => (
                  <tr key={r.id} className="border-b">
                    <td className="py-2">{r.type === "EXTERNAL" ? "Externa" : "Interna"}</td>
                    <td className="py-2">{r.company || r.offerTitle}</td>
                    <td className="py-2">{r.status || "PENDIENTE"}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </section>
      </main>
    </div>
  );
}
