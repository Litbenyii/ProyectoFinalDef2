const API_URL = "http://localhost:4000";

async function request(path, options = {}) {
  const { headers, ...rest } = options;

  const res = await fetch(`${API_URL}${path}`, {
    ...rest,
    headers: {
      "Content-Type": "application/json",
      ...(headers || {}),
    },
  });

  let data = null;
  try {
    data = await res.json();
  } catch (_) {}

  if (!res.ok) {
    const msg = data?.message || data?.error || "Error en la solicitud";

    if (res.status === 401) {
      localStorage.removeItem("token");
      localStorage.removeItem("user");
      window.location.href = "/";
    }

    throw new Error(msg);
  }

  return data;
}

/* =====================
   AUTH
===================== */

export function login(email, password) {
  return request("/api/auth/login", {
    method: "POST",
    body: JSON.stringify({ email, password }),
  });
}

/* =====================
   STUDENT
===================== */

export function getOffers(token) {
  return request("/api/student/offers", {
    headers: { Authorization: `Bearer ${token}` },
  });
}

export function getMyRequests(token) {
  return request("/api/student/my/requests", {
    headers: { Authorization: `Bearer ${token}` },
  });
}

export function createPracticeRequest(token, payload) {
  return request("/api/student/practice-requests", {
    method: "POST",
    headers: { Authorization: `Bearer ${token}` },
    body: JSON.stringify(payload),
  });
}

export function createApplication(token, offerId) {
  return request(`/api/student/applications/${offerId}`, {
    method: "POST",
    headers: { Authorization: `Bearer ${token}` },
  });
}

/* =====================
   COORDINATOR – EXTERNAL PRACTICES
===================== */

export function getCoordinatorPracticeRequests(token) {
  return request("/api/coordinator/external-requests", {
    headers: { Authorization: `Bearer ${token}` },
  });
}

export function approvePracticeRequest(token, id) {
  return request(`/api/coordinator/external-requests/${id}/approve`, {
    method: "POST",
    headers: { Authorization: `Bearer ${token}` },
  });
}

export function rejectPracticeRequest(token, id) {
  return request(`/api/coordinator/external-requests/${id}/reject`, {
    method: "POST",
    headers: { Authorization: `Bearer ${token}` },
  });
}

/* =====================
   COORDINATOR – OFFERS
===================== */

export function getCoordOffers(token) {
  return request("/api/coordinator/offers", {
    headers: { Authorization: `Bearer ${token}` },
  });
}

export function createOffer(token, payload) {
  return request("/api/coordinator/offers", {
    method: "POST",
    headers: { Authorization: `Bearer ${token}` },
    body: JSON.stringify(payload),
  });
}

export function deactivateOffer(token, id) {
  return request(`/api/coordinator/offers/${id}`, {
    method: "PUT",
    headers: { Authorization: `Bearer ${token}` },
  });
}

/* =====================
   COORDINATOR – APPLICATIONS
===================== */

export function getCoordinatorApplications(token) {
  return request("/api/coordinator/applications", {
    headers: { Authorization: `Bearer ${token}` },
  });
}

export function approveApplication(token, id) {
  return request(`/api/coordinator/applications/${id}/approve`, {
    method: "POST",
    headers: { Authorization: `Bearer ${token}` },
  });
}

export function rejectApplication(token, id) {
  return request(`/api/coordinator/applications/${id}/reject`, {
    method: "POST",
    headers: { Authorization: `Bearer ${token}` },
  });
}

/* =====================
   COORDINATOR – STUDENTS
===================== */

export function createStudent(token, payload) {
  return request("/api/coordinator/students", {
    method: "POST",
    headers: { Authorization: `Bearer ${token}` },
    body: JSON.stringify(payload),
  });
}

/* =====================
   COORDINATOR – EVALUATORS & PRACTICES
===================== */

export function getEvaluators(token) {
  return request("/api/coordinator/evaluators", {
    headers: { Authorization: `Bearer ${token}` },
  });
}

export function getOpenPractices(token) {
  return request("/api/coordinator/open-practices", {
    headers: { Authorization: `Bearer ${token}` },
  });
}

export function assignEvaluatorToPractice(token, practiceId, evaluatorId) {
  return request(
    `/api/coordinator/practices/${practiceId}/assign-evaluator`,
    {
      method: "POST",
      headers: { Authorization: `Bearer ${token}` },
      body: JSON.stringify({ evaluatorId }),
    }
  );
}
