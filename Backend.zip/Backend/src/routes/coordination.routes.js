const express = require("express");
const router = express.Router();
const {
  listOffersController,
  createOfferController,
  deactivateOfferController,
  createStudentController,
  listExternalRequests
} = require("../controllers/coordination.controller");
const { authMiddleware, requireCoordination } = require("../middleware/auth");

router.use(authMiddleware, requireCoordination);

// --- OFERTAS ---
router.get("/offers", listOffersController); // Para listar
router.post("/offers", createOfferController); // Para crear

// SOPORTE PARA DESACTIVAR (El api.js usa PUT y el ID directo)
router.put("/offers/:id", deactivateOfferController); 
router.post("/offers/:id/deactivate", deactivateOfferController);

// --- SOLICITUDES EXTERNAS (El api.js busca 'external-requests') ---
router.get("/external-requests", listExternalRequests); 
router.get("/practice-requests", listExternalRequests); // Por si acaso

// --- ESTUDIANTES ---
router.post("/students", createStudentController);

module.exports = router;