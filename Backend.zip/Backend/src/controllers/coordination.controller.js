const { listAllOffers, createOffer, deactivateOffer } = require("../services/offer.service");
const { createStudent } = require("../services/student.service");

async function createOfferController(req, res) {
  try {
    const offer = await createOffer(req.body, req.user.id);
    return res.status(201).json(offer);
  } catch (error) {
    console.error("Error al crear:", error);
    return res.status(500).json({ message: error.message });
  }
}

async function deactivateOfferController(req, res) {
  try {
    const { id } = req.params;
    await deactivateOffer(id);
    return res.json({ message: "Oferta procesada correctamente" });
  } catch (error) {
    return res.status(500).json({ message: "Error al eliminar la oferta" });
  }
}

async function listOffersController(req, res) {
  try {
    const offers = await listAllOffers();
    return res.json(offers);
  } catch (error) {
    return res.status(500).json({ message: "Error al obtener ofertas" });
  }
}

async function listExternalRequests(req, res) {
  // Retornamos array vacío para que el frontend no de error 404 mientras implementas
  return res.json([]); 
}

async function createStudentController(req, res) {
  try {
    const result = await createStudent(req.body);
    return res.status(201).json(result);
  } catch (error) {
    return res.status(500).json({ message: "Error al crear estudiante" });
  }
}

module.exports = {
  createOfferController,
  listOffersController,
  deactivateOfferController,
  createStudentController,
  listExternalRequests
};