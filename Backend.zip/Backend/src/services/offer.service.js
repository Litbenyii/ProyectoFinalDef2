const pool = require("../config/db");

async function createOffer(data, userId) {
  // Extraemos datos. Si el frontend envía 'details' en lugar de 'description', lo capturamos.
  const title = data.title;
  const company = data.company;
  const description = data.description || data.details; // <--- Soporta ambos nombres
  const location = data.location || 'No especificada';
  const hours = parseInt(data.hours) || 0;
  const modality = data.modality || 'Presencial';

  if (!title || !company || !description) {
    throw new Error("Faltan campos obligatorios: Título, Empresa y Descripción.");
  }

  // IMPORTANTE: Asegúrate que userId no sea null (viene del token)
  const result = await pool.query(
    `INSERT INTO offers (title, company, location, hours, modality, description, created_by)
     VALUES ($1, $2, $3, $4, $5, $6, $7)
     RETURNING *`,
    [title, company, location, hours, modality, description, userId]
  );
  return result.rows[0];
}

module.exports = { 
    createOffer, 
    listAllOffers: async () => {
        const res = await pool.query("SELECT * FROM offers ORDER BY created_at DESC");
        return res.rows;
    },
    deactivateOffer: async (id) => {
        return await pool.query("DELETE FROM offers WHERE id = $1", [id]);
    }
};