const pool = require("../config/db");

/**
 * Crear solicitud de práctica externa
 */
async function createPracticeRequest(studentId, payload) {
  const {
    companyName,
    tutorName,
    tutorEmail,
    startDate,
    endDate,
    details,
  } = payload;

  if (!studentId || !companyName) {
    throw new Error("Faltan datos obligatorios de la solicitud");
  }

  const result = await pool.query(
    `
    INSERT INTO practice_requests
      (student_id, company, tutor_name, tutor_email, start_date, end_date, details, status)
    VALUES
      ($1, $2, $3, $4, $5, $6, $7, 'pending')
    RETURNING *
    `,
    [
      studentId,
      companyName,
      tutorName,
      tutorEmail,
      startDate,
      endDate,
      details || "",
    ]
  );

  return result.rows[0];
}

/**
 * Obtener solicitudes de práctica (coordinador)
 */
async function getCoordinatorPracticeRequests() {
  const result = await pool.query(
    `
    SELECT
      pr.*,
      s.full_name,
      s.career,
      u.email
    FROM practice_requests pr
    JOIN students s ON pr.student_id = s.id
    JOIN app_users u ON s.user_id = u.id
    ORDER BY pr.created_at DESC
    `
  );

  return result.rows;
}

/**
 * Actualizar estado de solicitud
 */
async function updatePracticeRequestStatus(id, status) {
  const result = await pool.query(
    `
    UPDATE practice_requests
    SET status = $1
    WHERE id = $2
    RETURNING *
    `,
    [status, id]
  );

  return result.rows[0];
}

/**
 * Obtener prácticas (todas)
 */
async function getPractices() {
  const result = await pool.query(
    `
    SELECT
      p.*,
      s.full_name,
      u.email,
      e.name AS evaluator_name
    FROM practices p
    JOIN students s ON p.student_id = s.id
    JOIN app_users u ON s.user_id = u.id
    LEFT JOIN evaluators e ON p.approved_by = e.id
    ORDER BY p.created_at DESC
    `
  );

  return result.rows;
}

/**
 * Listar evaluadores
 */
async function getEvaluators() {
  const result = await pool.query(
    `
    SELECT *
    FROM evaluators
    ORDER BY name ASC
    `
  );

  return result.rows;
}

/**
 * Asignar evaluador a práctica
 */
async function assignEvaluatorToPractice(practiceId, evaluatorId) {
  const result = await pool.query(
    `
    UPDATE practices
    SET approved_by = $1
    WHERE id = $2
    RETURNING *
    `,
    [evaluatorId, practiceId]
  );

  return result.rows[0];
}

/**
 * Cerrar práctica (lógica simple)
 * → aquí solo dejamos constancia (no status)
 */
async function closePractice(practiceId) {
  const result = await pool.query(
    `
    UPDATE practices
    SET end_date = CURRENT_DATE
    WHERE id = $1
    RETURNING *
    `,
    [practiceId]
  );

  return result.rows[0];
}

async function getOpenPractices() {
  const result = await pool.query(`
    SELECT *
    FROM practices
    WHERE approved_by IS NULL
    ORDER BY created_at DESC
  `);
  return result.rows;
}


module.exports = {
  createPracticeRequest,
  getCoordinatorPracticeRequests,
  updatePracticeRequestStatus,
  getPractices,
  getOpenPractices, 
  getEvaluators,
  assignEvaluatorToPractice,
  closePractice,
};
