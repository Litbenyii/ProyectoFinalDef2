const pool = require("../config/db");
const bcrypt = require("bcryptjs");

// Crear estudiante + usuario
async function createStudent(data) {
  const { fullName, rut, email, career } = data;

  if (!fullName || !rut || !email) {
    throw new Error("Faltan datos obligatorios del estudiante");
  }

  // Contraseña inicial desde RUT (últimos 6 dígitos)
  const password =
    rut.replace(/\./g, "").replace("-", "").slice(-6) || "123456";

  const hashedPassword = await bcrypt.hash(password, 10);

  // 1️⃣ Crear usuario base
  const userResult = await pool.query(
    `
    INSERT INTO app_users (email, password, role)
    VALUES ($1, $2, 'student')
    RETURNING id, email, role
    `,
    [email, hashedPassword]
  );

  const user = userResult.rows[0];

  // 2️⃣ Crear estudiante
  const studentResult = await pool.query(
    `
    INSERT INTO students (user_id, full_name, rut, career)
    VALUES ($1, $2, $3, $4)
    RETURNING *
    `,
    [user.id, fullName, rut, career]
  );

  const student = studentResult.rows[0];

  return {
    user,
    student,
    initialPassword: password,
  };
}

// Obtener estudiante por user_id
async function getStudentByUserId(userId) {
  const result = await pool.query(
    `
    SELECT *
    FROM students
    WHERE user_id = $1
    `,
    [userId]
  );

  return result.rows[0] || null;
}

module.exports = {
  createStudent,
  getStudentByUserId,
};
